Para compilar, basta usar o comando 
$make
nesta pasta.

Para executar o servidor:
$./server PORTA NOME_DA_SALA

Para executar o cliente:
$./client IP_SERVIDOR PORTA NOME_DO_CLIENTE
