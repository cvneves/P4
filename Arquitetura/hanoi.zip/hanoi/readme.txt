para compilar:
nasm -f elf32 hanoiFinal.asm && gcc -m32 -o hanoiFinal hanoiFinal.o
